


@interface SBIconLabelView : UIView



@end
